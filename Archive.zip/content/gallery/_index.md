---
title: "Gallery"
draft: false
---

Below are some images processed by Hugo Pipes shortcode.
{{< gallery dir="images" >}}